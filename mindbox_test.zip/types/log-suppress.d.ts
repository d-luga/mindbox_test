declare module "log-suppress" {
  function init(console: Console): void;

  export { init };
}
